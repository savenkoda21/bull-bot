
import logging
from telegram import Update
from telegram.ext import ApplicationBuilder, CommandHandler, MessageHandler, filters, ContextTypes

TOKEN = "8020312103:AAH-jUV4SQEME1TeZ_69blADBcG5R3NWk_I"

logging.basicConfig(format='%(asctime)s - %(name)s - %(levelname)s - %(message)s', level=logging.INFO)

catalog = []

async def start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.message.reply_text("👋 Привет! Я бот для подбора быков по заданным параметрам.\n\nДоступные команды:\n/подбор — подобрать быков\n/обновить — добавить быка в каталог")

async def handle_selection(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if not text.startswith("/подбор"):
        return

    response = "🔍 Результаты подбора быков:\n\n1. Бык A – Молоко +2200 л, Вымя +2.5, Ноги +1.8\n2. Бык B – Молоко +2100 л, Здоровье +2.1, Фертильность +1.7"
    await update.message.reply_text(response)

async def handle_update(update: Update, context: ContextTypes.DEFAULT_TYPE):
    text = update.message.text
    if not text.startswith("/обновить"):
        return

    catalog.append(text)
    await update.message.reply_text("✅ Данные быка временно добавлены в каталог.")

if __name__ == '__main__':
    app = ApplicationBuilder().token(TOKEN).build()

    app.add_handler(CommandHandler("start", start))
    app.add_handler(MessageHandler(filters.TEXT & filters.Regex("^/подбор"), handle_selection))
    app.add_handler(MessageHandler(filters.TEXT & filters.Regex("^/обновить"), handle_update))

    app.run_polling()
